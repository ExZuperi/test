#!/bin/sh

cd ..
git clone --depth 1 https://github.com/CISOfy/lynis-sdk

#EOF
